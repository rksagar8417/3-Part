package com.example.woodmarkingcalculator

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.util.Locale
import kotlin.math.floor

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { CalculatorScreen() } }
    }
}

private fun fmt(v: Double): String =
    if (v % 1.0 == 0.0) v.toLong().toString()
    else String.format(Locale.US, "%.1f", v)

@Composable
fun CalculatorScreen() {
    var length by remember { mutableStateOf("2715") }
    var edge by remember { mutableStateOf("50") }
    var spacing by remember { mutableStateOf("150") }
    val context = LocalContext.current

    val l = length.toDoubleOrNull()
    val e = edge.toDoubleOrNull()
    val s = spacing.toDoubleOrNull()
    val valid = l != null && e != null && s != null &&
            l > 0 && e >= 0 && s > 0 && l >= 2 * e

    val positions = remember(length, edge, spacing) {
        val ll = length.toDoubleOrNull()
        val ee = edge.toDoubleOrNull()
        val ss = spacing.toDoubleOrNull()
        if (ll == null || ee == null || ss == null ||
            ll <= 0 || ee < 0 || ss <= 0 || ll < 2 * ee) {
            emptyList()
        } else {
            val usable = ll - 2 * ee
            val gaps = floor(usable / ss).toInt()
            val remainderEachSide = (usable - gaps * ss) / 2.0
            val first = ee + remainderEachSide
            (0..gaps).map { first + it * ss }
        }
    }

    val first = positions.firstOrNull()
    val last = positions.lastOrNull()
    val rear = if (l != null && last != null) l - last else null

    Scaffold { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("Wood Marking Calculator", style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold)
                Text("लकड़ी पर बराबर दूरी से निशान लगाने का कैलकुलेटर")
            }
            item {
                NumberField("लकड़ी की कुल लंबाई (mm)", length) { length = it }
                NumberField("आगे और पीछे छोड़ना (mm)", edge) { edge = it }
                NumberField("निशानों के बीच दूरी (mm)", spacing) { spacing = it }
            }
            item {
                if (valid && first != null && last != null) {
                    Card {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("आपका हिसाब", style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold)
                            ResultLine("कुल निशान", positions.size.toString())
                            ResultLine("पहला निशान", "${fmt(first)} mm")
                            ResultLine("आखिरी निशान", "${
                                fmt(last)
                            } mm")
                            ResultLine("आगे खाली", "${fmt(first)} mm")
                            ResultLine("पीछे खाली", "${fmt(rear!!)} mm")
                            ResultLine("हर निशान के बीच", "${fmt(s!!)} mm")
                            Button(onClick = {
                                val report = buildString {
                                    appendLine("Wood Marking Calculator")
                                    appendLine("लकड़ी: ${fmt(l!!)} mm")
                                    appendLine("कुल निशान: ${positions.size}")
                                    appendLine("पहला निशान: ${fmt(first)} mm")
                                    appendLine("दूरी: ${fmt(s)} mm")
                                    appendLine("आखिरी निशान: ${fmt(last)} mm")
                                    appendLine("आगे खाली: ${fmt(first)} mm")
                                    appendLine("पीछे खाली: ${fmt(rear)} mm")
                                    appendLine("सभी निशान (एक किनारे से):")
                                    positions.forEachIndexed { i, p ->
                                        appendLine("${i + 1}. ${fmt(p)} mm")
                                    }
                                }
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("Marking calculation", report))
                            }, modifier = Modifier.fillMaxWidth()) {
                                Text("पूरा हिसाब कॉपी करें")
                            }
                        }
                    }
                } else {
                    Text("कृपया सही माप डालें। लंबाई, छोड़ी जाने वाली जगह से बड़ी होनी चाहिए।",
                        color = MaterialTheme.colorScheme.error)
                }
            }
            item {
                Text("हर निशान की माप (एक किनारे से)", style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold)
            }
            if (positions.isNotEmpty()) {
                items(positions.mapIndexed { i, p -> "${i + 1}.  ${fmt(p)} mm" }) { row ->
                    Text(row, modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp))
                    HorizontalDivider()
                }
            }
            item {
                Text("नोट: यह अधिकतम पूरे अंतराल रखता है और बची हुई जगह दोनों सिरों पर बराबर बाँटता है।",
                    style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun NumberField(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { new -> if (new.all { it.isDigit() || it == '.' }) onValueChange(new) },
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun ResultLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label)
        Text(value, fontWeight = FontWeight.SemiBold)
    }
}
