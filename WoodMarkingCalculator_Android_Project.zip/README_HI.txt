WOOD MARKING CALCULATOR - Android project

यह Android Studio में खुलने वाला प्रोजेक्ट है। APK बनाने के लिए:

1. कंप्यूटर में Android Studio इंस्टॉल करें।
2. इस ZIP को Extract करें।
3. Android Studio में Open चुनें और WoodMarkingCalculator फ़ोल्डर खोलें।
4. Gradle Sync पूरा होने दें।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
6. APK आम तौर पर app/build/outputs/apk/debug/app-debug.apk में मिलेगा।
7. APK को अपने Android फोन में भेजकर इंस्टॉल करें। फोन में जरूरत पड़ने पर "Install unknown apps" की अनुमति दें।

गणना का नियम:
- उपयोग योग्य लंबाई = कुल लंबाई - दोनों किनारों की छोड़ी जगह
- पूरे अंतराल = floor(उपयोग योग्य लंबाई / अंतराल)
- निशान = पूरे अंतराल + 1
- बची हुई लंबाई दोनों सिरों पर बराबर बाँटी जाती है।

उदाहरण:
2715 mm, दोनों तरफ 50 mm, अंतराल 150 mm:
18 निशान, पहला 82.5 mm, आखिरी 2632.5 mm।
